$(document).ready(function(){

  // Slider

      $('.slider').bxSlider({
        auto: true,
        controls: false,
        pager: false
      });

});
